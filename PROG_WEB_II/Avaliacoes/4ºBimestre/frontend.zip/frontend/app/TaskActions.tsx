// app/TaskActions.tsx
'use client';

import { useRouter } from 'next/navigation';
import { Task, API_URL } from './types'; // Importa a interface Task

interface TaskActionsProps {
  task: Task;
}

export default function TaskActions({ task }: TaskActionsProps) {
  const router = useRouter();
  const taskUrl = `${API_URL}${task.id}/`; // URL específica da tarefa

  // UPDATE (PATCH) - Alterna o status 'completed'
  const handleToggleCompleted = async () => {
    const res = await fetch(taskUrl, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
      },
      // Envia apenas o campo 'completed' invertido
      body: JSON.stringify({ completed: !task.completed }), 
    });

    if (res.ok) {
      router.refresh(); // Gatilha a re-busca de dados no Server Component
    } else {
      alert('Erro ao atualizar tarefa!');
    }
  };

  // DELETE - Remove a tarefa
  const handleDelete = async () => {
    if (window.confirm('Tem certeza que deseja deletar esta tarefa?')) {
      const res = await fetch(taskUrl, {
        method: 'DELETE',
      });

      if (res.ok) {
        router.refresh(); // Gatilha a re-busca de dados
      } else {
        alert('Erro ao deletar tarefa!');
      }
    }
  };

  return (
    <div style={{ marginTop: '5px' }}>
      <button 
        onClick={handleToggleCompleted} 
        style={{ 
          marginRight: '10px', 
          backgroundColor: task.completed ? '#f9f9f9' : '#4CAF50', 
          color: task.completed ? '#333' : 'white',
          border: '1px solid #ccc',
          cursor: 'pointer'
        }}
      >
        {task.completed ? '↩️ Marcar como Pendente' : '✅ Concluir'}
      </button>
      <button 
        onClick={handleDelete} 
        style={{ backgroundColor: 'red', color: 'white', border: '1px solid red', cursor: 'pointer' }}
      >
        🗑️ Deletar
      </button>
    </div>
  );
}