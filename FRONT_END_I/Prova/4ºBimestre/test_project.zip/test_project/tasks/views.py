from rest_framework import viewsets
from .models import Task
from .serializers import TaskSerializer

class TaskViewSet(viewsets.ModelViewSet):
    # Define o conjunto de dados a ser usado (todas as tarefas)
    queryset = Task.objects.all().order_by('created_at')
    # Define o Serializer a ser usado para conversão JSON
    serializer_class = TaskSerializer




