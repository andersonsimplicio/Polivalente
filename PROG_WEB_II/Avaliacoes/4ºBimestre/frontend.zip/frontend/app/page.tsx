// app/page.tsx

import { Task, API_URL } from './types';
import AddTask from './AddTask'; 
import TaskActions from './TaskActions'; 
import { Suspense } from 'react';

// Função para buscar dados - Executada no Servidor Next.js
async function getTasks(): Promise<Task[]> {
  const res = await fetch(API_URL, {
    // Garante que a lista não é cacheadada estaticamente (bom para APIs dinâmicas)
    cache: 'no-store', 
  });

  if (!res.ok) {
    console.error('Falha ao buscar tarefas:', res.status, await res.text());
    // Se a API estiver offline, retorna um erro amigável.
    throw new Error('Não foi possível conectar à API de Tarefas. Verifique o backend Django.'); 
  }
  
  return res.json();
}

// Componente de Apresentação (Renderizado no Servidor)
async function TaskList() {
    const tasks = await getTasks();

    return (
        <ul>
            {tasks.map(task => (
                <li 
                    key={task.id} 
                    style={{ 
                        listStyleType: 'none', 
                        padding: '10px 0', 
                        borderBottom: '1px solid #eee',
                        textDecoration: task.completed ? 'line-through' : 'none',
                        opacity: task.completed ? 0.6 : 1
                    }}
                >
                    <p><strong>{task.title}</strong></p>
                    {task.description && <p style={{ fontSize: '0.9em', color: '#555' }}>{task.description}</p>}
                    
                    {/* TaskActions é um Client Component que lida com o PATCH/DELETE */}
                    <TaskActions task={task} /> 
                </li>
            ))}
        </ul>
    );
}

// Layout Principal da Página
export default function HomePage() {
  return (
    <main style={{ padding: '20px', maxWidth: '600px', margin: 'auto' }}>
      <h1>Lista de Tarefas (Full-Stack TS)</h1>
      
      {/* AddTask é um Client Component que lida com o POST */}
      <AddTask /> 

      <h2>Minhas Tarefas:</h2>
      
      {/* Suspense é opcional, mas permite exibir um loading enquanto a busca carrega */}
      <Suspense fallback={<div>Carregando tarefas...</div>}>
          <TaskList />
      </Suspense>
    </main>
  );
}