from django import forms
from .models import Agendamento
from datetime import datetime

class AgendamentoForm(forms.ModelForm):
    class Meta:
        model = Agendamento
        fields = ["cliente", "telefone", "servico", "profissional", "data", "hora", "observacoes"]

    def clean(self):
        cleaned = super().clean()
        data = cleaned.get("data")
        hora = cleaned.get("hora")
        profissional = cleaned.get("profissional")
        servico = cleaned.get("servico")

        # 1) Proíbe passado
        if data and hora:
            dt = datetime.combine(data, hora)
            if dt < datetime.now():
                raise forms.ValidationError("Não é possível agendar em data/horário passados.")

        # 2) (Opcional) Verifica se o profissional atende o serviço escolhido
        if servico and profissional and profissional.especialidades.exists():
            if servico not in profissional.especialidades.all():
                raise forms.ValidationError("Este(a) profissional não executa o serviço selecionado.")

        # 3) Conflito já é pego pelo unique_together, mas podemos avisar antes:
        if data and hora and profissional:
            from .models import Agendamento as Ag
            conflito = Ag.objects.filter(profissional=profissional, data=data, hora=hora)
            if self.instance.pk:
                conflito = conflito.exclude(pk=self.instance.pk)
            if conflito.exists():
                raise forms.ValidationError("Conflito de horário: este(a) profissional já está agendado(a).")

        return cleaned

