from django.shortcuts import render

# Create your views here.
def relatorio_aluno(request):
    templates="alunos/relatorio.html"
    aluno = {
        'nome': 'Mirella',
        'turma': '3° Ano 3',
        'notas': [
            {'materia': 'Matemática', 'nota': 10.0},
            {'materia': 'Português', 'nota': 9.5},
            {'materia': 'História', 'nota': 6.0},
            {'materia': 'Geografia', 'nota': 9.0}
        ]
    }

    # Cálculo da média
    soma = sum(n['nota'] for n in aluno['notas'])
    media = soma / len(aluno['notas'])

    contexto = {
        'pipa': aluno,
        'media': media,
        'status': 'Aprovado' if media >= 7 else 'Reprovado'
    }

    return render(request, templates, contexto)