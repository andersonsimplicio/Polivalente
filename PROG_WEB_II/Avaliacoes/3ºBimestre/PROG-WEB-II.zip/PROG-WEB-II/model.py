from django.db import models

class Tarefa(models.Model):
    titulo = models.CharField(max_length=200, verbose_name="Título")
    feita = models.BooleanField(default=False, verbose_name="Concluída")
    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-criado_em"]   # ordena pelo mais recente
        verbose_name = "Tarefa"
        verbose_name_plural = "Tarefas"

    def __str__(self):
        return self.titulo