from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name="home"),
    path('agendar/', views.agendar, name="agendar"),
    path('lista/', views.listar, name="listar"),
    path('excluir/<int:pk>/', views.excluir, name="excluir"),
]


