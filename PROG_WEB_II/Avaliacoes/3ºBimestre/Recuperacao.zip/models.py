from django.db import models

class Servico(models.Model):
    nome = models.CharField(max_length=60, unique=True)
    duracao_min = models.PositiveIntegerField(default=30)  # p/ extensões futuras

    class Meta:
        ordering = ["nome"]

    def __str__(self):
        return self.nome

class Profissional(models.Model):
    nome = models.CharField(max_length=80, unique=True)
    especialidades = models.ManyToManyField(Servico, blank=True)

    class Meta:
        ordering = ["nome"]

    def __str__(self):
        return self.nome

class Agendamento(models.Model):
    cliente = models.CharField(max_length=100)
    telefone = models.CharField(max_length=20)
    servico = models.ForeignKey(Servico, on_delete=models.PROTECT)
    profissional = models.ForeignKey(Profissional, on_delete=models.PROTECT)
    data = models.DateField()
    hora = models.TimeField()
    observacoes = models.TextField(blank=True)
    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["data", "hora"]
        # evita dois agendamentos no MESMO horário para o MESMO profissional
        unique_together = (("profissional", "data", "hora"),)

    def __str__(self):
        return f"{self.cliente} - {self.servico} ({self.profissional}) {self.data} {self.hora}"


