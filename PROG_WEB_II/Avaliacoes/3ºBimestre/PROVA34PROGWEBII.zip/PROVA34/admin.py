from django.contrib import admin

# Register your models here.
# despesas/admin.py
from django.contrib import admin
from django.db.models import Sum
from django.http import HttpResponse
import csv

from .models import Categoria, Despesa


# --------- Ação utilitária: exportar despesas selecionadas para CSV ----------
@admin.action(description="Exportar despesas selecionadas para CSV")
def exportar_despesas_csv(modeladmin, request, queryset):
    response = HttpResponse(content_type="text/csv; charset=utf-8")
    response["Content-Disposition"] = 'attachment; filename="despesas.csv"'
    writer = csv.writer(response)
    # Cabeçalho
    writer.writerow(["Data", "Descrição", "Categoria", "Valor", "Owner"])
    for d in queryset.select_related("categoria"):
        writer.writerow([
            d.data.strftime("%Y-%m-%d"),
            d.descricao,
            d.categoria.nome if d.categoria_id else "",
            f"{d.valor:.2f}",
            getattr(d.owner, "username", "") if hasattr(d, "owner") and d.owner else "",
        ])
    return response


# --------- Inline: mostrar despesas dentro da categoria ----------
class DespesaInline(admin.TabularInline):
    model = Despesa
    extra = 0
    fields = ("data", "descricao", "valor")
    ordering = ("-data",)
    show_change_link = True


# --------- Categoria ----------
@admin.register(Categoria)
class CategoriaAdmin(admin.ModelAdmin):
    list_display = ("nome", "total_gasto", "criado_em")
    search_fields = ("nome",)
    ordering = ("nome",)
    inlines = [DespesaInline]

    @admin.display(description="Total gasto")
    def total_gasto(self, obj):
        total = obj.despesas.aggregate(s=Sum("valor"))["s"]
        return f"R$ {total:.2f}" if total else "—"


# --------- Despesa ----------
@admin.register(Despesa)
class DespesaAdmin(admin.ModelAdmin):
    # Mostra colunas úteis na lista
    list_display = (
        "data",
        "descricao",
        "categoria",
        "valor_formatado",
        "owner_display",       # comente se não usar owner
        "criado_em",
    )
    list_display_links = ("descricao",)

    # Filtros laterais
    list_filter = (
        ("data", admin.DateFieldListFilter),
        "categoria",
        # "owner",  # descomente se usar owner
    )

    # Busca
    search_fields = ("descricao", "categoria__nome")

    # Navegação por data
    date_hierarchy = "data"

    # Autocomplete (útil quando há muitas categorias/usuários)
    autocomplete_fields = (
        "categoria",
        # "owner",  # descomente se usar owner
    )

    # Ordenação padrão
    ordering = ("-data", "-criado_em")

    # Campos no formulário de edição/criação
    fieldsets = (
        (None, {
            "fields": ("descricao", "valor", "data", "categoria")
        }),
        ("Meta", {
            "classes": ("collapse",),
            "fields": ("owner",),  # remova se não usar owner
        }),
    )

    # Ações customizadas
    actions = [exportar_despesas_csv]

    # --------- Helpers / exibidores ---------
    @admin.display(description="Valor (R$)")
    def valor_formatado(self, obj):
        return f"R$ {obj.valor:.2f}"

    @admin.display(description="Owner")
    def owner_display(self, obj):
        return getattr(obj.owner, "username", "—") if hasattr(obj, "owner") and obj.owner else "—"

    # --------- Total agregado no changelist ---------
    # Adiciona "total_filtrado" ao contexto do changelist (sum dos resultados filtrados)
    def changelist_view(self, request, extra_context=None):
        response = super().changelist_view(request, extra_context=extra_context)
        try:
            cl = response.context_data["cl"]
            qs = cl.queryset
            total = qs.aggregate(total=Sum("valor"))["total"] or 0
            extra = extra_context or {}
            extra.update({"total_filtrado": total})
            response.context_data.update(extra)
        except Exception:
            pass
        return response
