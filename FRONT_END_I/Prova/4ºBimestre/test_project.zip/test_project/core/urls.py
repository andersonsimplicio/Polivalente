
from django.contrib import admin
from django.urls import path,include

urlpatterns = [
    path('admin/', admin.site.urls),
    # Inclua as rotas da nossa API no prefixo 'api/v1/'
    path('api/v1/', include('tasks.urls')), 
]



