from rest_framework.routers import DefaultRouter
from .views import TaskViewSet

# Cria um roteador e registra o ViewSet
router = DefaultRouter()
router.register(r'tasks', TaskViewSet)

# O router gera URLs para todas as operações CRUD
urlpatterns = router.urls