export interface Task {
  id: number;
  title: string;
  description: string;
  completed: boolean;
  created_at: string; // Ou Date, se você for parsear
}

export const API_URL = process.env.NEXT_PUBLIC_DJANGO_API_URL || 'http://127.0.0.1:8000/api/v1/tasks/';