'use client'; 

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { API_URL } from './types';

export default function AddTask() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const router = useRouter(); // Usado para recarregar o Server Component

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const res = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ title, description }),
      });

      if (res.ok) {
        setTitle('');
        setDescription('');
        // Sinaliza ao Next.js para re-executar o Server Component (getTasks)
        router.refresh(); 
      } else {
        alert('Erro ao criar tarefa! Verifique o console.');
      }
    } catch (error) {
      console.error('Erro de rede:', error);
      alert('Erro de conexão com a API.');
    }
  };

  // ... (Estrutura do formulário é a mesma do exemplo anterior em JS)
  return (
    <form onSubmit={handleSubmit} style={{ border: '1px solid #ccc', padding: '15px', marginBottom: '20px' }}>
      <input
        type="text"
        placeholder="Título da Tarefa"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        required
        style={{ padding: '8px', marginRight: '10px' }}
      />
      <input
        type="text"
        placeholder="Descrição (Opcional)"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        style={{ padding: '8px', marginRight: '10px' }}
      />
      <button type="submit" style={{ padding: '8px 15px' }}>➕ Adicionar</button>
    </form>
  );
}