from django.shortcuts import render

# Create your views here.
from decimal import Decimal
from django.db.models import Sum
from django.shortcuts import render, redirect, get_object_or_404
from django.utils.dateparse import parse_date

from .models import Despesa, Categoria


def lista_despesas(request):
    qs = Despesa.objects.select_related("categoria").order_by("-data", "-criado_em")

    # Escopo por usuário (se quiser separar por dono)
    if request.user.is_authenticated:
        qs = qs.filter(owner=request.user)

    # Filtros GET
    ano = request.GET.get("ano", "").strip()
    mes = request.GET.get("mes", "").strip()
    categoria_id = request.GET.get("categoria", "").strip()

    if ano:
        qs = qs.filter(data__year=ano)
    if mes:
        qs = qs.filter(data__month=mes)
    if categoria_id:
        qs = qs.filter(categoria_id=categoria_id)

    # Agregações
    total = qs.aggregate(total=Sum("valor"))["total"] or Decimal("0")
    por_categoria = (
        qs.values("categoria__nome")
          .annotate(total=Sum("valor"))
          .order_by("-total")
    )

    categorias = Categoria.objects.order_by("nome")
    anos_disponiveis = (
        Despesa.objects.values_list("data__year", flat=True)
                       .distinct().order_by("-data__year")
    )

    contexto = {
        "despesas": qs,
        "categorias": categorias,
        "anos_disponiveis": anos_disponiveis,
        "filtros": {"ano": ano, "mes": mes, "categoria": categoria_id},
        "total": total,
        "por_categoria": por_categoria,
    }
    return render(request, "despesas/lista.html", contexto)


def criar_despesa(request):
    if request.method == "POST":
        descricao = (request.POST.get("descricao") or "").strip()
        valor_str = (request.POST.get("valor") or "").replace(",", ".").strip()
        data_str = (request.POST.get("data") or "").strip()
        categoria_id = (request.POST.get("categoria") or "").strip()

        errors = []
        if not descricao:
            errors.append("Informe a descrição.")
        try:
            valor = Decimal(valor_str)
            if valor <= 0:
                errors.append("O valor deve ser maior que 0.")
        except Exception:
            errors.append("Informe um valor válido (ex.: 123.45).")
            valor = None

        data = parse_date(data_str)
        if data is None:
            errors.append("Informe uma data válida (YYYY-MM-DD).")

        categoria = None
        if not categoria_id:
            errors.append("Selecione uma categoria.")
        else:
            categoria = Categoria.objects.filter(pk=categoria_id).first()
            if not categoria:
                errors.append("Categoria inválida.")

        if errors:
            return render(
                request,
                "despesas/criar.html",
                {
                    "errors": errors,
                    "descricao": descricao,
                    "valor": valor_str,
                    "data": data_str,
                    "categoria_id": categoria_id,
                    "categorias": Categoria.objects.order_by("nome"),
                },
            )

        despesa = Despesa(
            descricao=descricao,
            valor=valor,
            data=data,
            categoria=categoria,
        )
        if request.user.is_authenticated:
            despesa.owner = request.user
        despesa.save()
        return redirect("despesas:lista")

    return render(
        request,
        "despesas/criar.html",
        {"categorias": Categoria.objects.order_by("nome")},
    )
