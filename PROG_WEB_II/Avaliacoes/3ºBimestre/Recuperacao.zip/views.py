from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .forms import AgendamentoForm
from .models import Agendamento, Servico, Profissional

def seed_basico():
    """Cria alguns serviços/profissionais se não existirem (atividade didática)."""
    if not Servico.objects.exists():
        s1 = Servico.objects.create(nome="Corte feminino", duracao_min=45)
        s2 = Servico.objects.create(nome="Escova", duracao_min=40)
        s3 = Servico.objects.create(nome="Manicure", duracao_min=30)
        s4 = Servico.objects.create(nome="Pedicure", duracao_min=30)
        s5 = Servico.objects.create(nome="Maquiagem", duracao_min=60)
    else:
        s1, s2, s3, s4, s5 = Servico.objects.all()[:5]

    if not Profissional.objects.exists():
        p1 = Profissional.objects.create(nome="Aline")
        p2 = Profissional.objects.create(nome="Bruna")
        p3 = Profissional.objects.create(nome="Carla")
        # especialidades (apenas exemplo)
        p1.especialidades.set([s1, s2, s5])
        p2.especialidades.set([s1, s3, s4])
        p3.especialidades.set([s2, s5, s3])

def home(request):
    seed_basico()  # garante dados iniciais
    return redirect("agendar")

def agendar(request):
    seed_basico()
    if request.method == "POST":
        form = AgendamentoForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Agendamento criado com sucesso!")
            return redirect("listar")
    else:
        form = AgendamentoForm()
    return render(request, "agendamentos/agendar.html", {"form": form})

def listar(request):
    qs = Agendamento.objects.all()
    return render(request, "agendamentos/listar.html", {"agendamentos": qs})

def excluir(request, pk):
    ag = get_object_or_404(Agendamento, pk=pk)
    if request.method == "POST":
        ag.delete()
        messages.success(request, "Agendamento excluído.")
        return redirect("listar")
    return render(request, "agendamentos/confirmar_exclusao.html", {"obj": ag})

