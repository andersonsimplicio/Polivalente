from rest_framework import serializers
from .models import Task

class TaskSerializer(serializers.ModelSerializer):
    class Meta:
        model = Task
        # Inclua todos os campos do modelo na API
        fields = '__all__'
        # Opcional: marque 'created_at' como read-only
        read_only_fields = ('created_at',)
    
    
    