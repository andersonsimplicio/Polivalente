from django.urls import path
from . import views

app_name = "despesas"

urlpatterns = [
    path("", views.lista_despesas, name="lista"),
    path("nova/", views.criar_despesa, name="criar"),
]

