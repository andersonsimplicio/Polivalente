// app/layout.tsx

import type { Metadata } from "next";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    // Aplique a supressão no elemento HTML
    <html lang="pt-BR" suppressHydrationWarning={true}> 
      <body>{children}</body>
    </html>
  );
}