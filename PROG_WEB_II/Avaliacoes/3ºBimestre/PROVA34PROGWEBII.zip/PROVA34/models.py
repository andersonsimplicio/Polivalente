from django.db import models

# Create your models here.
from decimal import Decimal
from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models


class Categoria(models.Model):
    nome = models.CharField(
        max_length=60,
        unique=True,
        verbose_name="Nome da categoria"
    )
    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["nome"]
        verbose_name = "Categoria"
        verbose_name_plural = "Categorias"

    def __str__(self):
        return self.nome


class Despesa(models.Model):
    # Se quiser multiusuário, deixe owner; se for projeto de um usuário só, pode remover este campo.
    owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name="despesas",
        null=True,
        blank=True,
        verbose_name="Usuário (dono)"
    )

    descricao = models.CharField(max_length=120, verbose_name="Descrição")
    valor = models.DecimalField(
        max_digits=10,
        decimal_places=2,
        validators=[MinValueValidator(Decimal("0.01"))],
        verbose_name="Valor (R$)"
    )
    data = models.DateField(verbose_name="Data da despesa")
    categoria = models.ForeignKey(
        Categoria,
        on_delete=models.PROTECT,
        related_name="despesas",
        verbose_name="Categoria"
    )

    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["-data", "-criado_em"]
        indexes = [
            models.Index(fields=["data"]),
            models.Index(fields=["categoria", "data"]),
        ]
        verbose_name = "Despesa"
        verbose_name_plural = "Despesas"

    def __str__(self):
        return f"{self.descricao} — R$ {self.valor:.2f} em {self.data:%d/%m/%Y}"
