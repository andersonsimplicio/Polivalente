from django.urls import path
from alunos.views import relatorio_aluno
urlpatterns = [
    path('',relatorio_aluno,name='home'),
]